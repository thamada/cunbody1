// Time-stamp: <2008-07-07 20:08:41 hamada>

/*
 * Copyright (C) 2007 
 *      Tsuyoshi Hamada <hamada@progrape.jp>
 *      All rights reserved.
 * This code is released under version 2 of the GNU GPL.
 */

#define IDIM  (4)
#define JDIM  (4)
#define FDIM  (3)


#include <cunbody_api.h>

extern "C" void copyright_cunbody1(void);

void copyright_cunbody1(void)
{
  printf("Copyright(C) 2007 by Tsuyoshi Hamada <hamada@progrape.jp>, All rights reserved.\n");
}


static double T_Force = 0.0;
static double T_Write = 0.0;
static double T_Calc  = 0.0;
static double T_Read  = 0.0;
static unsigned ni_sum = 0;
static unsigned nj_sum = 0;
static double n_inter = 0.0;


extern "C" void cunbody_dumptime(void);

void
_cunbody_dumptime(void)
{
  printf("----------------------------------\n");
  printf("Time: %f |\t W(%f)\t C(%f)\t R(%f)\n",T_Force, T_Write, T_Calc, T_Read);
  printf("MB/s: %f \t %f\n",
	 (1.0e-6)*(sizeof(float)*ni_sum*IDIM+sizeof(float)*nj_sum*JDIM)/T_Write,
	 (1.0e-6)*(sizeof(float)*ni_sum*FDIM)/T_Read);

  printf("Gflop/s: %f \n",(1.0e-9)*n_inter*38.0/T_Calc);
  printf("Gflop/s: %f \n",(1.0e-9)*n_inter*38.0/T_Force);
  printf("n inter %e \n", n_inter);
  printf("\n");

  T_Force = T_Write = T_Calc = T_Read = 0.0;
  ni_sum = 0;
  nj_sum = 0;
  n_inter = 0.0;
}

void
cunbody_dumptime(void){ }




