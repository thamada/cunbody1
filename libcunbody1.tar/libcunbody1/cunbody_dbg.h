/*
 * Time-stamp: <2007-02-14 12:55:48 hamada>
 * 
 * Macros to help debugging
 *
 * Copyright (C) 2007, Tsuyoshi Hamada
 *
 * 2007-02-11  Designed by Tsuyoshi Hamada.
 *
 */

#define DEBUG 1

#undef DOUT             /* undef it, just in case */
#ifdef DEBUG
#  ifdef __DEVICE_EMULATION__
/* This one if debugging is on, and emulator space */
#    define DOUT(fmt, args...) printf( fmt, ## args)
#  else
/* This one for non emulatior space */
#    define DOUT(fmt, args...) /* not debugging: nothing */
#  endif
#else
#  define DOUT(fmt, args...) /* not debugging: nothing */
#endif

#undef _DOUT
#define _DOUT(fmt, args...) /* nothing: it's a placeholder */



//---------------------- for kernel internal
// ++++++++ 
#undef CUNBODY_THREAD_INFO
#ifdef __DEVICE_EMULATION__
#  define  CUNBODY_THREAD_INFO  printf( "BLOCK=%d/%d, PIPE=%d/%d\n", blockIdx.x, gridDim.x, threadIdx.x, blockDim.x)
#else
#  define  CUNBODY_THREAD_INFO   /* nothing: it's a placeholder */
#endif

#undef  _CUNBODY_THREAD_INFO
#define _CUNBODY_THREAD_INFO     /* nothing: it's a placeholder */

// ++++++++ 
#undef CUNBODY_EMU_CALL
#ifdef __DEVICE_EMULATION__
#  define  CUNBODY_EMU_CALL(X) X
#else
#  define  CUNBODY_EMU_CALL(X)     /* erase */
#endif

// ++++++++ 
#undef CUNBODY_EMU_CALL
#ifdef __DEVICE_EMULATION__
#  define  CUNBODY_EMU_CALL(X) X
#else
#  define  CUNBODY_EMU_CALL(X)     /* erase */
#endif

// ++++++++ 
#undef CUNBODY_EMU_SLEEP
#ifdef __DEVICE_EMULATION__
#include <unistd.h>
#  define  CUNBODY_EMU_SLEEP(x) usleep(x)
#else
#  define  CUNBODY_EMU_SLEEP(x) usleep(x)
#endif
